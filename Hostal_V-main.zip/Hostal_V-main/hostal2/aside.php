<ASIDE>
				<H4>Consultas Rápidas</H4>
				<UL>
					<LI><A href="clientes.php" title="Crear nuevo cliente">Crear Cliente</A></LI>
					<LI><A href="reservas.php" title="Crear nueva reserva">Ver habitaciones libres</A></LI>
				
					
				</UL>
			</ASIDE>
