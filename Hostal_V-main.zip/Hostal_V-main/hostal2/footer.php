    <footer>
        <p>&copy; 2024 Panel de Administración Hotel</p>
    </footer>
    <script src="js/scripts.js"></script>
</body>
</html>
