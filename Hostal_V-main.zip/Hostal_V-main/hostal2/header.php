<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <title>Administración Hotel</title>
</head>
<body>
    <header>
        <img src="img/logo.png" alt="Logotipo del sitio">
        <h1>Panel de Administración Hotel</h1>
    </header>
    
    <?php include('menu-principal.php'); ?>
