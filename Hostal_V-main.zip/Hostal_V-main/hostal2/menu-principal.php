<nav>
    <ul>
        <li><a href="index.php">Inicio</a></li>
        <li><a href="clientes.php">Clientes</a></li>
        <li><a href="reservas.php">Reservas</a></li>
        
    </ul>
</nav>
