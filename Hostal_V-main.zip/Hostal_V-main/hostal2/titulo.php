<HEADER id="cajaTitulo">
			<FIGURE>
				<IMG src="./img/logo.png" alt="Mi Logo" title="Logotipo del sitio web" longdesc="http://www.miweb.es/index.html#descripcionweb" />
				<FIGCAPTION>
					<H1 id="titulo">Panel de Administración Hotel</H1>
					<P id="descripcionweb">Administrar desde este panel clientes y habitaciones</P>
				</FIGCAPTION>
			</FIGURE>
		</HEADER>
